# SCRAPING-IMDB-site
In which I scrap top 250 movies details in that there was 14 task which I completed in this. 
